package com.commit451.easel.sample;

import android.content.Context;
import android.support.v7.app.AppCompatDialog;

/**
 * Created by Jawn on 7/28/2015.
 */
public class ColorDialog extends AppCompatDialog {

    public ColorDialog(Context context) {
        super(context);
    }
}
